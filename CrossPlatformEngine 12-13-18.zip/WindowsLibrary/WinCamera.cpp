//#include "stdafx.h"
#include "WinCamera.h"


WinCamera::WinCamera()
{
}


WinCamera::~WinCamera()
{
}

void WinCamera::InitialiseCamera(int h, int w)
{

}

//glm::mat4 WinCamera::GetViewMatrix()
//{
//	return viewMatrix;
//}
//
//glm::mat4 WinCamera::GetWorldMatrix()
//{
//	return worldMatrix;
//}
//
//glm::mat4 WinCamera::GetProjectionMatrix()
//{
//	return projectionMatrix;
//}
