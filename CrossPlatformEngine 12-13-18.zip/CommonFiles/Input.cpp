#include "Input.h"




Input::Input()
{

}


Input::~Input()
{
}

//bool Input::GetKeyDown(const unsigned char keycode)
//{
//	return false;
//}

int Input::initialize()
{
	return 0;
}

//void Input::update()
//{
//}

//bool Input::isButtonDown(uint32_t buttons, ButtonEventPattern pattern)
//{
//	return false;
//}

