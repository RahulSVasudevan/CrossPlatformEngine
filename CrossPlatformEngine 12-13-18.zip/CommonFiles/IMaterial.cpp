#include"IMaterial.h"


IMaterial::IMaterial()
{
}

IMaterial::IMaterial(IRenderer * renderer, const char * obj)
{
}

IMaterial::~IMaterial()
{
}

//void IMaterial::LoadTextures(const char *obj)
//{
//}

void IMaterial::DatatoShader()
{
}
