#include "IAudio.h"
//#include "stdafx.h"


IAudio::IAudio()
{
}

IAudio::~IAudio()
{
}

void IAudio::Init()
{
}

void IAudio::Play(char * audioSound)
{
}

void IAudio::Graphics()
{
}

void IAudio::End()
{
}
