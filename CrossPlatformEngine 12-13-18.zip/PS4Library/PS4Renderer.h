#pragma once

#include "..\CommonFiles\IRenderer.h"
#include"..\CommonFiles\IEntity.h"
#include"..\CommonFiles\IMaterial.h"
#include "PS4Mesh.h"
#include <sceconst.h>
#include <kernel.h>
#include <gnmx.h>
#include "sceFiles\stack_allocator.h"
#include "sceFiles\embedded_shader.h"
#include "sceFiles\shaderbinary.h"
#include "sceFiles\video_out.h"
#include "..\PS4Library\ControllerInput.h"
#include"..\PS4Library\PS4Entity.h"
#include "PS4Camera.h"
#include "shader_base.h"
#include <math.h>
#include <stdio.h>
#include <vectormath.h>


using namespace std;
using namespace sce::Vectormath::Scalar::Aos;

#define PI 3.14159

#define DISPLAY_WIDTH				1920
#define DISPLAY_HEIGHT				1080

// vertex counting for where everything goes in the global array
// fixed number of vertices for cone and sphere
#define CONE_VERTEX_COUNT 12
#define LINE_VERTEX_COUNT 2
#define SPHERE_VERTEX_COUNT 288
#define SPHERE_SIZE 0.25f

// initial indices where data starts getting drawn for different data types
static int line_index = 0;
static int cone_index = line_index + LINE_VERTEX_COUNT;
static int sphere_index = cone_index + CONE_VERTEX_COUNT;


// Mark variable as used
#define	UNUSED(a)					(void)(a)


// Helper macro to align a value
#define ALIGN(x, a)					(((x) + ((a) - 1)) & ~((a) - 1))

#define POINT_SETS 1


struct Buffer
{
	sce::Gnm::RenderTarget       m_renderTarget;
	sce::Gnm::DepthRenderTarget  m_depthTarget;
	sce::Gnm::DepthRenderTarget dbTarget;
	volatile uint64_t           *m_label;
	uint32_t                     m_expectedLabel;
};

// Data structure for basic geometry
typedef struct BasicVertex {
	float x;
	float y;
	float z;

	BasicVertex() { x = 0.0f; y = 0.0f; z = 0.0f; }
	BasicVertex(float x, float y, float z) { this->x = x; this->y = y; this->z = z; }
	BasicVertex operator+(const BasicVertex& rhs) {
		return BasicVertex(this->x + rhs.x, this->y + rhs.y, this->z + rhs.z);
	}
	BasicVertex operator+(const float& rhs) {
		return BasicVertex(this->x + rhs, this->y + rhs, this->z += rhs);
	}
	BasicVertex operator*(const BasicVertex& rhs) {
		return BasicVertex(this->x * rhs.x, this->y * rhs.y, this->z *= rhs.z);
	}
	BasicVertex operator*(const float& rhs) {
		return BasicVertex(this->x * rhs, this->y * rhs, this->z * rhs);
	}

} BasicVertex;

// For simplicity reasons the sample uses a single GfxContext for each
// display buffer. Implementing more complex schemes where multiple
// GfxContext-s are submitted in each frame is possible as well, but it is
// out of the scope for this basic sample.
typedef struct DisplayBuffer
{
	sce::Gnmx::GfxContext        gfxContext;
	void                   *cpRamShadow;
	void                   *cueHeap;
	void                   *dcbBuffer;
	void                   *ccbBuffer;
	sce::Gnm::RenderTarget       renderTarget;
	sce::Gnm::DepthRenderTarget  depthTarget;
	volatile uint32_t      *state;
} DisplayBuffer;

enum DisplayBufferState
{
	kDisplayBufferIdle = 0,
	kDisplayBufferInUse
};

struct MyConst
{
	glm::mat4 m_modelViewProjection;
	glm::mat4 m_model;
};

struct LightStruct
{
	DirectionalLight Light;
};


class PS4Renderer : public IRenderer
{
	int pointsSize;
	int windowX;
	int windowY;
	
	// sony program vars
	Matrix4	mainViewProjMatrix;
	int err;
	sce::Gnm::DataFormat format; // render target pixel format

	// create allocators
	StackAllocator s_garlicAllocator;
	StackAllocator s_onionAllocator;
	
	sce::Gnmx::VsShader *vertexShader;
	sce::Gnmx::PsShader *pixelShader;
	
	LightStruct* lightingStruct;
	MyConst *constants;
	uint32_t kDisplayBufferWidth = DISPLAY_WIDTH;
	uint32_t kDisplayBufferHeight = DISPLAY_HEIGHT;
	uint32_t kDisplayBufferCount = 2;

	sce::Gnm::ZFormat kZFormat = sce::Gnm::kZFormat32Float;
	sce::Gnm::StencilFormat kStencilFormat = sce::Gnm::kStencil8;
	bool kHtileEnabled = true;
	Vector4 kClearColor;
	uint32_t kCueRingEntries = 16;
	uint32_t kDcbSizeInBytes = 2 * 1024 * 1024;
	uint32_t kCcbSizeInBytes = 2 * 1024 * 1024;
	uint32_t kOnionRegionsCount = 128;
	int32_t kGarlicRegionsCount = 128;
	int videoOutHandle;
	SceKernelEqueue eopEventQueue;
	void *surfaceAddresses[2];
	DisplayBuffer *backBuffer;
	uint32_t backBufferIndex = 0;
	sce::Gnm::SizeAlign stencilSizeAlign;
	sce::Gnm::SizeAlign htileSizeAlign;
	sce::Gnm::SizeAlign depthTargetSizeAlign;
	void *stencilMemory = NULL;
	void *depthMemory;
	SceVideoOutBufferAttribute videoOutBufferAttribute;
	BasicVertex *vertexData;
	uint16_t *indexData;
	sce::Gnm::Buffer vertexBuffers;
	int vertexSize;
	uint32_t shaderModifier;
	void *fsMem;
	sce::Gnmx::GfxContext *gfxc;

	void *allocateMemory(sce::Gnm::SizeAlign sizeAlign);
	void *allocateMemory(uint32_t size, sce::Gnm::AlignmentType align);
	void *allocateOnionMemory(uint32_t size, sce::Gnm::AlignmentType align);
	sce::Gnmx::VsShader* LoadVsShaderFromMemory(const void *pointer);
	sce::Gnmx::PsShader* LoadPsShaderFromMemory(const void *pointer);
	void registerRenderTargetForDisplay(sce::Gnm::RenderTarget *renderTarget);
	void requestFlipAndWait();
	void generateVsFetchShader(void *fs, uint32_t *shaderModifier, const sce::Gnmx::VsShader *vsb, const sce::Gnm::FetchShaderInstancingMode *instancingData);

public:

	PS4Renderer();
	~PS4Renderer();
	void Init();
	void MessageLoop();
	bool MessageExist();
	void BeginFrame();
	void EndFrame();
	void DrawQuad();
	ICamera * camera;
	void DrawMesh(void* Entity, void* Material);
	void LightingInfo(DirectionalLight light);
	void checkInput(char);

	sce::Gnmx::VsShader * getVertexShader();
	sce::Gnmx::PsShader* getPixelShader();
	StackAllocator* GetStackAllocater();
	sce::Gnmx::GfxContext * GetContext();
};