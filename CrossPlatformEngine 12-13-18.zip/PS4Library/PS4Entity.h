#pragma once
#include"../CommonFiles/IEntity.h"
#include"../CommonFiles/IMaterial.h"
#include "../CommonFiles/Maths.h"
#include "PS4Material.h"
//#include "../framework/gnf_loader.h"
//#include "../framework/frame.h"
#include"PS4Mesh.h"
#include"../PS4Library/PS4Renderer.h"
//#include"../CommonFiles/IRenderer.h"



using namespace glm;

//namespace
//{
//	Framework::GnmSampleFramework framework;
//
//}
class PS4Entity	: public IEntity
{	vec4 position;
	vec3 rotation;
	vec3 scaleValue;
	IMesh* mesh;
	IMaterial* material;
	IRenderer* Renderer;
	sce::Gnmx::VsShader * localvertexShader;
	sce::Gnmx::PsShader * localpixelShader;
	/*DirectionalLight Light;*/
	/*ID3D11ShaderResourceView* SRV;
	ID3D11SamplerState* Sampler;*/

public:
	PS4Entity(IMesh* m, IMaterial* mat);
	mat4x4 worldMatrix;
	vec3 wmTrans;
	vec3 wmScale;
	vec3 wmRot;
	void setTranslation(float, float, float);
	void setScale(float, float, float);
	void setRotation(float, float, float);
	PS4Mesh* GetMesh();
	void updateWorld();

	mat4x4 GetWorldMatrix();
	~PS4Entity();
};