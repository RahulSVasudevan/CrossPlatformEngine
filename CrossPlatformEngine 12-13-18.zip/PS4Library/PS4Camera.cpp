#include "PS4Camera.h"

PS4Camera::PS4Camera()
{
}

PS4Camera::~PS4Camera()
{
}

void PS4Camera::InitialiseCamera(int h, int w)
{
	
	int height = h;
	int width = w;


	cameraPos = glm::vec3(0.0f, 0.0f, 20.0f);

	cameraTarget = glm::vec3(0.0f, 0.0f, 0.0f);
	//cameraDirection = glm::normalize(cameraPos - cameraTarget);
	//cameraDirection = glm::vec3(0.0f, -0.5f, -1.0f);

	up = glm::vec3(0.0f, 1.0f, 0.0f);
	//front = glm::vec3(0.0f, 0.0f, 1.0f);
	cameraRight = glm::normalize(glm::cross(up, cameraTarget));

	//cameraUp = glm::cross(cameraDirection, cameraRight);

	//cameraFront = glm::cross(cameraUp, cameraRight);

	viewMatrix = glm::lookAt(cameraPos,
		cameraTarget,
		up);

	viewMatrix = glm::transpose(viewMatrix);

	worldMatrix = glm::mat4(1.0f);

	projectionMatrix = glm::perspective(45.0f * 3.1415926535f / 180.0f, (float)height / width, 0.1f, 1000.0f);

	projectionMatrix = glm::transpose(projectionMatrix);
	
}

glm::mat4 PS4Camera::GetViewMatrix()
{
	return viewMatrix;
}

glm::mat4 PS4Camera::GetWorldMatrix()
{
	return worldMatrix;
}
glm::mat4 PS4Camera::GetProjectionMatrix()
{
	return projectionMatrix;
}
