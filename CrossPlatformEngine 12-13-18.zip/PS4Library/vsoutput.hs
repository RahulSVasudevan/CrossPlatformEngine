/* SCE CONFIDENTIAL
PlayStation(R)4 Programmer Tool Runtime Library Release 02.000.071
* Copyright (C) 2013 Sony Computer Entertainment Inc.
* All Rights Reserved.
*/

#ifndef __VSOUTPUT_H__
#define __VSOUTPUT_H__

struct VS_OUTPUT
{
    float4 Position     : S_POSITION;
	float4 Color		: COLOR0;
	float3 Normal		: NORMAL0;
	//float  Pad2			: PAD2;
	float2 UV			: TEXCOORD0;
	//float2 Pad3			: PAD3;
};



#endif