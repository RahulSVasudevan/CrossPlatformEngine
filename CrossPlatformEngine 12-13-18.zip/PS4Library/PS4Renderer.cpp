#include "PS4Renderer.h"

#include <cstdlib> 
#include <ctime> 
#include <cmath>
#include <iostream>
#include <cstdint>
#include <libdbg.h>
#include <vector>
#include <sceconst.h>

#include "shader_base.h"

using namespace std;
using namespace sce::Vectormath::Scalar::Aos;
using namespace sce;


size_t sceLibcHeapSize = 256 * 1024 * 1024;
unsigned int sceLibcHeapExtendedAlloc = 1; // Enable
// shader data
static const unsigned s_pix_p[] = {
#include "pix_p.h"
};

static const unsigned s_vex_vv[] = {
#include "vex_vv.h"
};


/////////////////////////////////
// Memory allocators
/////////////////////////////////
void *PS4Renderer::allocateMemory(sce::Gnm::SizeAlign sizeAlign)
{
	return s_garlicAllocator.allocate(sizeAlign.m_size, sizeAlign.m_align);
}

void *PS4Renderer::allocateMemory(uint32_t size, sce::Gnm::AlignmentType align)
{
	void *pointer = s_garlicAllocator.allocate(size, align);
	SCE_GNM_ASSERT_MSG(pointer, "allocate(%d,%d) returned NULL.", size, align);
	return pointer;
}

void *PS4Renderer::allocateOnionMemory(uint32_t size, sce::Gnm::AlignmentType align)
{
	void *pointer = s_onionAllocator.allocate(size, align);
	SCE_GNM_ASSERT_MSG(pointer, "allocate(%d,%d) returned NULL.", size, align);
	return pointer;
}

//////////////////////////////////////////////
// Shader functions
//////////////////////////////////////////////
// Video Out Infomation
struct VideoInfo {
	int32_t handle;
	uint64_t* label;
	uint32_t label_num;
	uint32_t flip_index;
	uint32_t buffer_num;
	SceKernelEqueue eq;
};
static VideoInfo s_videoInfo;


PS4Renderer::PS4Renderer()
{
	this->windowX = DISPLAY_WIDTH;
	this->windowY = DISPLAY_HEIGHT;
	camera = new ICamera();
}

PS4Renderer::~PS4Renderer()
{
	sceVideoOutClose(videoOutHandle);

	s_garlicAllocator.deinit();
	s_onionAllocator.deinit();
	delete camera;

}

DisplayBuffer displayBuffers[2];

void PS4Renderer::Init()
{

	int ret;

	int width = DISPLAY_WIDTH;
	int height = DISPLAY_HEIGHT;

	camera->InitialiseCamera(width, height);

	// Initialize the memory allocator
	s_garlicAllocator.init(SCE_KERNEL_WC_GARLIC, 1024 * 1024 * 512);
	s_onionAllocator.init(SCE_KERNEL_WB_ONION, 1024 * 1024 * 64);

	// init display buffers and set the initial buffer to one
	backBuffer = displayBuffers;
	backBufferIndex = 0;

	// initialize render target surface : b is in lsd for this one
	format = Gnm::kDataFormatB8G8R8A8UnormSrgb;

	// Open the video output port
	videoOutHandle = sceVideoOutOpen(0, SCE_VIDEO_OUT_BUS_TYPE_MAIN, 0, NULL);
	if (videoOutHandle < 0)
	{
		printf("sceVideoOutOpen failed: 0x%08X\n", videoOutHandle);
		return;
	}

	// Initialize the flip rate: 0: 60Hz, 1: 30Hz or 2: 20Hz
	ret = sceVideoOutSetFlipRate(videoOutHandle, 1);
	if (ret != SCE_OK)
	{
		printf("sceVideoOutSetFlipRate failed: 0x%08X\n", ret);
		return;
	}

	// Create the event queue for used to synchronize with end-of-pipe interrupts
	ret = sceKernelCreateEqueue(&eopEventQueue, "EOP QUEUE");
	if (ret != SCE_OK)
	{
		printf("sceKernelCreateEqueue failed: 0x%08X\n", ret);
		return;
	}

	// init display vars
	kClearColor = Vector4(0.5f, 0.5f, 0.5f, 1);

	// Register for the end-of-pipe events
	ret = Gnm::addEqEvent(eopEventQueue, Gnm::kEqEventGfxEop, NULL);
	if (ret != SCE_OK)
	{
		printf("Gnm::addEqEvent failed: 0x%08X\n", ret);
		return;
	}

	// Load the shader binaries from disk
	// init shaders
	vertexShader = LoadVsShaderFromMemory(s_vex_vv);
	pixelShader = LoadPsShaderFromMemory(s_pix_p);
	fsMem = s_garlicAllocator.allocate(
		Gnmx::computeVsFetchShaderSize(vertexShader),
		Gnm::kAlignmentOfFetchShaderInBytes);
	if (!fsMem)
	{
		printf("Cannot allocate the fetch shader memory\n");
		return;
	}

	// if we were instancing then this would have other arrays for 
	// scale, color, etc. in it
	const Gnm::FetchShaderInstancingMode instancingData[] =
	{
		Gnm::kFetchShaderUseVertexIndex,			 // Position
		Gnm::kFetchShaderUseVertexIndex,			//Pad1
		Gnm::kFetchShaderUseVertexIndex,			//color	
		Gnm::kFetchShaderUseVertexIndex,			//normal
		Gnm::kFetchShaderUseVertexIndex,			//pad2
		Gnm::kFetchShaderUseVertexIndex,			//uv
		Gnm::kFetchShaderUseVertexIndex				//pad3
	};

	Gnmx::generateVsFetchShader(fsMem, &shaderModifier, vertexShader, NULL);

	for (uint32_t i = 0; i<kDisplayBufferCount; ++i)
	{
		// for each display buffer allocated with rendering and graphical contexts
		// Allocate the CUE heap memory
		displayBuffers[i].cueHeap = s_garlicAllocator.allocate(
			Gnmx::ConstantUpdateEngine::computeHeapSize(kCueRingEntries),
			Gnm::kAlignmentOfBufferInBytes);

		if (!displayBuffers[i].cueHeap)
		{
			printf("Cannot allocate the CUE heap memory\n");
			return;
		}

		// Allocate the draw command buffer
		displayBuffers[i].dcbBuffer = s_onionAllocator.allocate(
			kDcbSizeInBytes,
			Gnm::kAlignmentOfBufferInBytes);

		if (!displayBuffers[i].dcbBuffer)
		{
			printf("Cannot allocate the draw command buffer memory\n");
			return;
		}

		// Allocate the constants command buffer
		displayBuffers[i].ccbBuffer = s_onionAllocator.allocate(
			kCcbSizeInBytes,
			Gnm::kAlignmentOfBufferInBytes);

		if (!displayBuffers[i].ccbBuffer)
		{
			printf("Cannot allocate the constants command buffer memory\n");
			return;
		}



		// Initialize the GfxContext used by this display buffer
		displayBuffers[i].gfxContext.init(
			displayBuffers[i].cueHeap,
			kCueRingEntries,
			displayBuffers[i].dcbBuffer,
			kDcbSizeInBytes,
			displayBuffers[i].ccbBuffer,
			kCcbSizeInBytes);
		////////////////////////////////////////////

		////////// Setting up the render target surface - tiling mode and memory
		Gnm::TileMode tileMode;
		Gnm::DataFormat format = Gnm::kDataFormatB8G8R8A8Unorm;
		ret = GpuAddress::computeSurfaceTileMode(
			&tileMode,										// Tile mode pointer
			GpuAddress::kSurfaceTypeColorTargetDisplayable,	// Surface type
			format,											// Surface format
			1);												// Elements per pixel
		if (ret != SCE_OK)
		{
			printf("GpuAddress::computeSurfaceTileMode: 0x%08X\n", ret);
			return;
		}

		// Initialize the render target descriptor
		Gnm::SizeAlign sizeAlign = displayBuffers[i].renderTarget.init(
			kDisplayBufferWidth,
			kDisplayBufferHeight,
			1,
			format,
			tileMode,
			Gnm::kNumSamples1,
			Gnm::kNumFragments1,
			NULL,
			NULL);

		// Allocate the render target memory
		surfaceAddresses[i] = s_garlicAllocator.allocate(sizeAlign);
		if (!surfaceAddresses[i])
		{
			printf("Cannot allocate the render target memory\n");
			return;
		}
		displayBuffers[i].renderTarget.setAddresses(surfaceAddresses[i], 0, 0);
		/////////////////////////////////////////////////////////////

		///////////////// init depth stencil surface

		// Compute the tiling mode for the depth buffer
		Gnm::DataFormat depthFormat = Gnm::DataFormat::build(kZFormat);
		Gnm::TileMode depthTileMode;
		ret = GpuAddress::computeSurfaceTileMode(
			&depthTileMode,									// Tile mode pointer
			GpuAddress::kSurfaceTypeDepthOnlyTarget,		// Surface type
			depthFormat,									// Surface format
			1);												// Elements per pixel
		if (ret != SCE_OK)
		{
			printf("GpuAddress::computeSurfaceTileMode: 0x%08X\n", ret);
			return;
		}

		// Initialize the depth buffer descriptor
		depthTargetSizeAlign = displayBuffers[i].depthTarget.init(
			kDisplayBufferWidth,
			kDisplayBufferHeight,
			depthFormat.getZFormat(),
			kStencilFormat,
			depthTileMode,
			Gnm::kNumFragments1,
			kStencilFormat != Gnm::kStencilInvalid ? &stencilSizeAlign : NULL,
			kHtileEnabled ? &htileSizeAlign : NULL);

		// Initialize the HTILE buffer, if enabled - HTILE is used for fast clears of depth targets
		if (kHtileEnabled)
		{
			void *htileMemory = s_garlicAllocator.allocate(htileSizeAlign);
			if (!htileMemory)
			{
				printf("Cannot allocate the HTILE buffer\n");
				return;
			}

			displayBuffers[i].depthTarget.setHtileAddress(htileMemory);
		}

		// Initialize the stencil buffer, if enabled
		if (kStencilFormat != Gnm::kStencilInvalid)
		{
			stencilMemory = s_garlicAllocator.allocate(stencilSizeAlign);
			if (!stencilMemory)
			{
				printf("Cannot allocate the stencil buffer\n");
				return;
			}
		}

		// Allocate the depth buffer
		void *depthMemory = s_garlicAllocator.allocate(depthTargetSizeAlign);
		if (!depthMemory)
		{
			printf("Cannot allocate the depth buffer\n");
			return;
		}
		displayBuffers[i].depthTarget.setAddresses(depthMemory, stencilMemory);

		displayBuffers[i].state = (volatile uint32_t*)s_onionAllocator.allocate(4, 8);
		if (!displayBuffers[i].state)
		{
			printf("Cannot allocate a GPU label\n");
			return;
		}

		displayBuffers[i].state[0] = kDisplayBufferIdle;
	}

	// Initialization the VideoOut buffer descriptor
	sceVideoOutSetBufferAttribute(
		&videoOutBufferAttribute,
		SCE_VIDEO_OUT_PIXEL_FORMAT_A8R8G8B8_SRGB,
		SCE_VIDEO_OUT_TILING_MODE_TILE,
		SCE_VIDEO_OUT_ASPECT_RATIO_16_9,
		backBuffer->renderTarget.getWidth(),
		backBuffer->renderTarget.getHeight(),
		backBuffer->renderTarget.getPitch());

	// Register the buffers to the slot: [0..kDisplayBufferCount-1]
	ret = sceVideoOutRegisterBuffers(
		videoOutHandle,
		0, // Start index
		surfaceAddresses,
		kDisplayBufferCount,
		&videoOutBufferAttribute);
	if (ret != SCE_OK)
	{
		printf("sceVideoOutRegisterBuffers failed: 0x%08X\n", ret);
		return;
	}

	// Allocate the vertex buffer memory
	vertexSize = 3;
	pointsSize = vertexSize * sizeof(BasicVertex);
	vertexData = static_cast<BasicVertex*>(s_garlicAllocator.allocate(
		pointsSize, Gnm::kAlignmentOfBufferInBytes));
	if (!vertexData)
	{
		printf("Cannot allocate vertex data\n");
		return;
	}

	// Allocate the vertex and index buffer memory
	indexData = static_cast<uint16_t*>(s_garlicAllocator.allocate(
		vertexSize * sizeof(uint16_t), Gnm::kAlignmentOfBufferInBytes));
	if (!indexData)
	{
		printf("Cannot allocate index data\n");
		return;
	}


	// test case triangle
	vertexData[0].x = -2.f;
	vertexData[0].y = -2.f;
	vertexData[0].z = -55.f;

	vertexData[1].x = 2.f;
	vertexData[1].y = -2.f;
	vertexData[1].z = -55.f;

	vertexData[2].x = 0.f;
	vertexData[2].y = 4.f;
	vertexData[2].z = -55.f;
	indexData[0] = 0;
	indexData[1] = 1;
	indexData[2] = 2;


//Initialize the vertex buffers pointing to each vertex element
	vertexBuffers.initAsVertexBuffer(
		&vertexData->x,
		Gnm::kDataFormatR32G32B32Float,
		sizeof(BasicVertex),
		pointsSize / sizeof(BasicVertex));

	// create shader constant
	constants = static_cast<MyConst*>(allocateMemory(sizeof(MyConst), Gnm::kAlignmentOfBufferInBytes));
	lightingStruct = static_cast<LightStruct*>(allocateMemory(sizeof(LightStruct), Gnm::kAlignmentOfBufferInBytes));
	const float depthNear = 0.1f, depthFar = 100.0f;
	const Point3 eyePosition(0, 0, -5.7), eyeTarget(0, 0, 0);
	const Vector3 eyeUp(0, 1, 0);
	const Vector3 objectRotZYX(0.0f, 0.0f, 0.0f);
	const Vector3 objectTrans(0.0f, 0.0f, 0.f);

	const float aspect = (float)DISPLAY_WIDTH / (float)DISPLAY_HEIGHT;
	const Matrix4 projectionMatrix = Matrix4::frustum(-aspect, aspect, -1, 1, depthNear, depthFar);
	const Matrix4 viewMatrix = Matrix4::lookAt(eyePosition, eyeTarget, eyeUp);
	const Matrix4 viewProjectionMatrix = projectionMatrix * viewMatrix;

	constants->m_modelViewProjection = camera->GetViewProjMatrix();

	constants->m_model = glm::mat4(1.0f);//ToMatrix4Unaligned(transpose(Matrix4::identity()));

	// Activate the VS and PS shader stages
	Gnmx::GfxContext &gfxc = backBuffer->gfxContext;
	Gnm::Buffer constBuffer;
	constBuffer.initAsConstantBuffer(constants, sizeof(MyConst));
	gfxc.setConstantBuffers(Gnm::kShaderStageVs, 0, 1, &constBuffer);

	gfxc.setActiveShaderStages(Gnm::kActiveShaderStagesVsPs);
	gfxc.setVsShader(vertexShader, shaderModifier, fsMem);
	gfxc.setPsShader(pixelShader);

	// Setup the output color mask
	gfxc.setRenderTargetMask(0xF);

}

void PS4Renderer::MessageLoop()
{
}

bool PS4Renderer::MessageExist()
{
	return true;
}



void PS4Renderer::BeginFrame()
{

	// set up for graphics context to be this buffer and not another
	gfxc = &backBuffer->gfxContext;

	// Flag the display buffer as "in use"
	backBuffer->state[0] = kDisplayBufferInUse;

	// Reset the graphical context and initialize the hardware state
	gfxc->reset();
	gfxc->initializeDefaultHardwareState();

	// The waitUntilSafeForRendering stalls the GPU until the scan-out
	// operations on the current display buffer have been completed.
	// This command is not blocking for the CPU.
	gfxc->waitUntilSafeForRendering(videoOutHandle, backBufferIndex);

	// Setup the viewport 
	gfxc->setupScreenViewport(
		0,			// Left
		0,			// Top
		backBuffer->renderTarget.getWidth(),
		backBuffer->renderTarget.getHeight(),
		0.5f,		// Z-scale
		0.5f);		// Z-offset

					// Bind the render & depth targets to the context
	gfxc->setRenderTarget(0, &backBuffer->renderTarget);
	gfxc->setDepthRenderTarget(&backBuffer->depthTarget);

	// Clear the color and the depth target
	// Use DMA to clear the render target. This is cleaner than clearing with a full-screen primitive, because it does not interact with graphics state
	// such as depth or stencil. Unfortunately, DMA can repeat only a 32-bit pattern, so all format conversion is the user's responsibility.
	Gnmx::fillData(&(gfxc->m_dcb), backBuffer->renderTarget.getBaseAddress(), 0xff000000, backBuffer->renderTarget.getSliceSizeInBytes(), Gnm::kDmaDataBlockingDisable); // 0xFF0000FF == deep blue

																																										// Flush and invalidate the HTILE buffer, then use DMA to clear the HTILE buffer. We are careful to clear the buffer's MinZ and MaxZ values to 1.f and 1.f, which corresponds to the depth clear value above.
																																										//
	uint8_t *htileAddr = static_cast<uint8_t*>(backBuffer->depthTarget.getHtileAddress());
	gfxc->m_dcb.triggerEvent(Gnm::kEventTypeFlushAndInvalidateDbMeta);
	Gnmx::fillData(&(gfxc->m_dcb), htileAddr, ~0xF, htileSizeAlign.m_size, Gnm::kDmaDataBlockingEnable); // ~0xF == min=1.f, max=1.f, zmask=0

																										// Enable z-writes using a less comparison function
	Gnm::DepthStencilControl dsc;
	dsc.init();
	dsc.setDepthControl(Gnm::kDepthControlZWriteEnable, Gnm::kCompareFuncLess);
	dsc.setDepthEnable(true);
	gfxc->setDepthStencilControl(dsc);
	gfxc->setDepthClearValue(1.0f);

	// setup prim and culling
	Gnm::PrimitiveSetup primSetupReg;
	primSetupReg.init();
	primSetupReg.setPolygonMode(Gnm::kPrimitiveSetupPolygonModeFill, Gnm::kPrimitiveSetupPolygonModeFill);
	gfxc->setPrimitiveSetup(primSetupReg);
	gfxc->setLineWidth(90);

	// Setup an additive blending mode
	Gnm::BlendControl blendControl;
	blendControl.init();
	blendControl.setBlendEnable(true);
	blendControl.setColorEquation(Gnm::kBlendMultiplierSrcAlpha, Gnm::kBlendFuncAdd, Gnm::kBlendMultiplierOneMinusSrcAlpha);
	gfxc->setBlendControl(0, blendControl);
}




void PS4Renderer::EndFrame()
{
	//Gnmx::GfxContext &gfxc = *gfxContext;
	
	gfxc->writeAtEndOfPipeWithInterrupt(
		Gnm::kEopFlushCbDbCaches,
		Gnm::kEventWriteDestMemory,
		(void*)backBuffer->state,
		Gnm::kEventWriteSource32BitsImmediate,
		kDisplayBufferIdle,
		Gnm::kCacheActionNone,
		Gnm::kCachePolicyLru);

	int ret = gfxc->submitAndFlip(
		videoOutHandle,
		backBufferIndex,
		SCE_VIDEO_OUT_FLIP_MODE_VSYNC,
		0);
	if (ret != sce::Gnm::kSubmissionSuccess)
	{
		printf("GfxContext::submitAndFlip failed: 0x%08X\n", ret);
		backBuffer->state[0] = kDisplayBufferIdle;
	}

	// Signal the system that every draw for this frame has been submitted.
	// This function gives permission to the OS to hibernate when all the
	// currently running GPU tasks (graphics and compute) are done.
	ret = Gnm::submitDone();
	if (ret != SCE_OK)
	{
		printf("Gnm::submitDone failed: 0x%08X\n", ret);
	}

	// Update the display chain pointers - double buffering
	backBufferIndex = (backBufferIndex + 1) % kDisplayBufferCount;
	backBuffer = displayBuffers + backBufferIndex;
}


void PS4Renderer::DrawQuad()
{
	int ret;

	// set up camera info
	Point3 eyePosMap(0.0f, 1.0f, 20.0f);
	Point3 lookAtPosMap(0.0f, 0.0f, 0.0f);
	Point3 eyePos(0.0f, 0.0f, -10.0f * cos(0.0));
	Point3 lookAtPos(0.0f, 0.0f, -11.0f * cos(0.0));
	mainViewProjMatrix
		= sce::Vectormath::Scalar::Aos::Matrix4::perspective(
			45.0f*SCE_MATH_PI / 180.0f,
			(float)(DISPLAY_WIDTH / 2.0f) / (float)DISPLAY_HEIGHT,
			0.1f,
			1000.0f)
		* sce::Vectormath::Scalar::Aos::Matrix4::lookAt(
			eyePosMap,
			lookAtPosMap,
			sce::Vectormath::Scalar::Aos::Vector3::yAxis())
		;
	constants->m_modelViewProjection = camera->GetViewProjMatrix();
	constants->m_model = glm::mat4(1.0f);//ToMatrix4Unaligned(transpose(Matrix4::identity()));

	// set up for graphics context to be this buffer and not another
	Gnmx::GfxContext &gfxc = backBuffer->gfxContext;

	// Flag the display buffer as "in use"
	backBuffer->state[0] = kDisplayBufferInUse;

	// Reset the graphical context and initialize the hardware state
	gfxc.reset();
	gfxc.initializeDefaultHardwareState();

	// The waitUntilSafeForRendering stalls the GPU until the scan-out
	// operations on the current display buffer have been completed.
	// This command is not blocking for the CPU.
	gfxc.waitUntilSafeForRendering(videoOutHandle, backBufferIndex);

	// Setup the viewport 
	gfxc.setupScreenViewport(
		0,			// Left
		0,			// Top
		backBuffer->renderTarget.getWidth(),
		backBuffer->renderTarget.getHeight(),
		0.5f,		// Z-scale
		0.5f);		// Z-offset

					// Bind the render & depth targets to the context
	gfxc.setRenderTarget(0, &backBuffer->renderTarget);
	gfxc.setDepthRenderTarget(&backBuffer->depthTarget);

	// Clear the color and the depth target
	// Use DMA to clear the render target. This is cleaner than clearing with a full-screen primitive, because it does not interact with graphics state
	// such as depth or stencil. Unfortunately, DMA can repeat only a 32-bit pattern, so all format conversion is the user's responsibility.
	Gnmx::fillData(&(gfxc.m_dcb), backBuffer->renderTarget.getBaseAddress(), 0xff000000, backBuffer->renderTarget.getSliceSizeInBytes(), Gnm::kDmaDataBlockingDisable); // 0xFF0000FF == deep blue

																																										// Flush and invalidate the HTILE buffer, then use DMA to clear the HTILE buffer. We are careful to clear the buffer's MinZ and MaxZ values to 1.f and 1.f, which corresponds to the depth clear value above.
																																										//
	uint8_t *htileAddr = static_cast<uint8_t*>(backBuffer->depthTarget.getHtileAddress());
	gfxc.m_dcb.triggerEvent(Gnm::kEventTypeFlushAndInvalidateDbMeta);
	Gnmx::fillData(&(gfxc.m_dcb), htileAddr, ~0xF, htileSizeAlign.m_size, Gnm::kDmaDataBlockingEnable); // ~0xF == min=1.f, max=1.f, zmask=0

																										// Enable z-writes using a less comparison function
	Gnm::DepthStencilControl dsc;
	dsc.init();
	dsc.setDepthControl(Gnm::kDepthControlZWriteEnable, Gnm::kCompareFuncLess);
	dsc.setDepthEnable(true);
	gfxc.setDepthStencilControl(dsc);
	gfxc.setDepthClearValue(1.0f);

	// setup prim and culling
	Gnm::PrimitiveSetup primSetupReg;
	primSetupReg.init();
	primSetupReg.setPolygonMode(Gnm::kPrimitiveSetupPolygonModeLine, Gnm::kPrimitiveSetupPolygonModeLine);
	gfxc.setPrimitiveSetup(primSetupReg);
	gfxc.setLineWidth(90);

	// Setup an additive blending mode
	Gnm::BlendControl blendControl;
	blendControl.init();
	blendControl.setBlendEnable(true);
	blendControl.setColorEquation(Gnm::kBlendMultiplierSrcAlpha, Gnm::kBlendFuncAdd, Gnm::kBlendMultiplierOneMinusSrcAlpha);
	gfxc.setBlendControl(0, blendControl);

	// Setup the vertex buffer 
	gfxc.setVertexBuffers(Gnm::kShaderStageVs, 0, 1, &vertexBuffers);

	// Activate the VS and PS shader stages
	gfxc.setActiveShaderStages(Gnm::kActiveShaderStagesVsPs);
	gfxc.setVsShader(vertexShader, shaderModifier, fsMem);
	gfxc.setPsShader(pixelShader);

	// setup the camera constants
	Gnm::Buffer constBuffer;
	constBuffer.initAsConstantBuffer(constants, sizeof(MyConst));
	gfxc.setConstantBuffers(Gnm::kShaderStageVs, 0, 1, &constBuffer);

	// Submit triangle draw call
	gfxc.m_cue.setVertexAndInstanceOffset(0, 0);
	gfxc.setPrimitiveType(Gnm::kPrimitiveTypeTriList);
	gfxc.setIndexSize(Gnm::kIndexSize16);
	gfxc.drawIndex(3, indexData);

	// Write the label that indicates that the GPU finished working on this frame
	// and trigger a software interrupt to signal the EOP event queue
	gfxc.writeAtEndOfPipeWithInterrupt(
		Gnm::kEopFlushCbDbCaches,
		Gnm::kEventWriteDestMemory,
		(void*)backBuffer->state,
		Gnm::kEventWriteSource32BitsImmediate,
		kDisplayBufferIdle,
		Gnm::kCacheActionNone,
		Gnm::kCachePolicyLru);

	// Submit the command buffers and request a flip of the display buffer.
	// NOTE: for this basic sample we are submitting a single GfxContext
	// per frame. Submitting multiple GfxContext-s per frame is allowed.
	// Multiple contexts are processed in order, i.e.: they start in
	// submission order and end in submission order.
	ret = gfxc.submitAndFlip(
		videoOutHandle,
		backBufferIndex,
		SCE_VIDEO_OUT_FLIP_MODE_VSYNC,
		0);
	if (ret != sce::Gnm::kSubmissionSuccess)
	{
		printf("GfxContext::submitAndFlip failed: 0x%08X\n", ret);
		backBuffer->state[0] = kDisplayBufferIdle;
	}

	// Signal the system that every draw for this frame has been submitted.
	// This function gives permission to the OS to hibernate when all the
	// currently running GPU tasks (graphics and compute) are done.
	ret = Gnm::submitDone();
	if (ret != SCE_OK)
	{
		printf("Gnm::submitDone failed: 0x%08X\n", ret);
	}

	// Update the display chain pointers - double buffering
	backBufferIndex = (backBufferIndex + 1) % kDisplayBufferCount;
	backBuffer = displayBuffers + backBufferIndex;

	
}






void PS4Renderer::DrawMesh(void * vEntity, void* vMaterial)
{
	PS4Entity* entity = reinterpret_cast<PS4Entity*>(vEntity);
	PS4Mesh* Mesh = entity->GetMesh();
	PS4Material* Mat = reinterpret_cast<PS4Material*>(vMaterial);

	/*
	// set up camera info
	Point3 eyePosMap(0.0f, 1.0f, 20.0f);
	Point3 lookAtPosMap(0.0f, 0.0f, 0.0f);
	Point3 eyePos(0.0f, 0.0f, -10.0f * cos(0.0));
	Point3 lookAtPos(0.0f, 0.0f, -11.0f * cos(0.0));
	mainViewProjMatrix
		= sce::Vectormath::Scalar::Aos::Matrix4::perspective(
			45.0f*SCE_MATH_PI / 180.0f,
			(float)(DISPLAY_WIDTH) / (float)DISPLAY_HEIGHT,
			0.1f,
			1000.0f)
		* sce::Vectormath::Scalar::Aos::Matrix4::lookAt(
			eyePosMap,
			lookAtPosMap,
			sce::Vectormath::Scalar::Aos::Vector3::yAxis())
		;
	constants->m_modelViewProjection = ToMatrix4Unaligned(transpose(mainViewProjMatrix));
	constants->m_model = transpose((Mesh)->GetWorldMatrix()); //ToMatrix4Unaligned(transpose(Matrix4::identity()));
	*/

	constants->m_modelViewProjection = camera->GetViewProjMatrix();
	constants->m_model = transpose(((IMesh*)Mesh)->GetWorldMatrix());






	//PS4Mesh* PMesh = reinterpret_cast<PS4Mesh*>(Mesh);
	gfxc->setVertexBuffers(Gnm::kShaderStageVs, 0, 4, Mesh->GetVertexBuffer());

	


	// Activate the VS and PS shader stages
	gfxc->setActiveShaderStages(Gnm::kActiveShaderStagesVsPs);
	gfxc->setVsShader(vertexShader, shaderModifier, fsMem);
	gfxc->setPsShader(pixelShader);


	

	// setup the camera constants
	Gnm::Buffer constBuffer;
	constBuffer.initAsConstantBuffer(constants, sizeof(MyConst));
	gfxc->setConstantBuffers(Gnm::kShaderStageVs, 0, 1, &constBuffer);

	//Lighting Info
	Gnm::Buffer pixelBuffer;
	pixelBuffer.initAsConstantBuffer(lightingStruct, sizeof(LightStruct));
	gfxc->setConstantBuffers(Gnm::kShaderStagePs, 0, 1, &pixelBuffer);

	//Texture Info
	gfxc->setTextures(Gnm::kShaderStagePs, 0, 1, Mat->getTexture());
	gfxc->setSamplers(Gnm::kShaderStagePs, 0, 1, &Mat->getSampler());


	// Submit triangle draw call
	gfxc->m_cue.setVertexAndInstanceOffset(0, 0);
	gfxc->setPrimitiveType(Gnm::kPrimitiveTypeTriList);
	gfxc->setIndexSize(Gnm::kIndexSize16);
	gfxc->drawIndex(Mesh->indexSize, Mesh->GetIndexData());

	

}


//void PS4Renderer::DrawMesh(void * Mesh)
//{
//	int ret;
//
//	// set up camera info
//	Point3 eyePosMap(0.0f, 1.0f, 20.0f);
//	Point3 lookAtPosMap(0.0f, 0.0f, 0.0f);
//	Point3 eyePos(0.0f, 0.0f, -10.0f * cos(0.0));
//	Point3 lookAtPos(0.0f, 0.0f, -11.0f * cos(0.0));
//	mainViewProjMatrix
//		= sce::Vectormath::Scalar::Aos::Matrix4::perspective(
//			45.0f*SCE_MATH_PI / 180.0f,
//			(float)(DISPLAY_WIDTH) / (float)DISPLAY_HEIGHT,
//			0.1f,
//			1000.0f)
//		* sce::Vectormath::Scalar::Aos::Matrix4::lookAt(
//			eyePosMap,
//			lookAtPosMap,
//			sce::Vectormath::Scalar::Aos::Vector3::yAxis())
//		;
//	constants->m_modelViewProjection = ToMatrix4Unaligned(transpose(mainViewProjMatrix));
//	constants->m_model = transpose(((IMesh*)Mesh)->GetWorldMatrix()); //ToMatrix4Unaligned(transpose(Matrix4::identity()));
//
//
//
//
//
//
//
//
//	PS4Mesh* PMesh = reinterpret_cast<PS4Mesh*>(Mesh);
//	gfxc->setVertexBuffers(Gnm::kShaderStageVs, 0,7, PMesh->GetVertexBuffer());
//
//
//
//
//	// Activate the VS and PS shader stages
//	gfxc->setActiveShaderStages(Gnm::kActiveShaderStagesVsPs);
//	gfxc->setVsShader(vertexShader, shaderModifier, fsMem);
//	gfxc->setPsShader(pixelShader);
//
//	// setup the camera constants
//	Gnm::Buffer constBuffer;
//	constBuffer.initAsConstantBuffer(constants, sizeof(MyConst));
//	gfxc->setConstantBuffers(Gnm::kShaderStageVs, 0, 1, &constBuffer);
//
//	//Lighting Info
//	Gnm::Buffer pixelBuffer;
//	pixelBuffer.initAsConstantBuffer(lightingStruct, sizeof(LightStruct));
//	gfxc->setConstantBuffers(Gnm::kShaderStagePs, 0, 1, &pixelBuffer);
//
//
//	// Submit triangle draw call
//	gfxc->m_cue.setVertexAndInstanceOffset(0, 0);
//	gfxc->setPrimitiveType(Gnm::kPrimitiveTypeTriList);
//	gfxc->setIndexSize(Gnm::kIndexSize16);
//	gfxc->drawIndex(PMesh->indexSize, PMesh->GetIndexData());
//
//
//
//}

StackAllocator* PS4Renderer::GetStackAllocater()
{
	return &s_garlicAllocator;
}

sce::Gnmx::GfxContext * PS4Renderer::GetContext()
{
	return gfxc;
}

void PS4Renderer::LightingInfo(DirectionalLight light)
{
	lightingStruct->Light = light;
}

void PS4Renderer::checkInput(char a)
{
	if (a == 'w')
		camera->moveFront();

	if (a == 's')
		camera->moveBack();

	if (a == 'a')
		camera->moveLeft();

	if (a == 'd')
		camera->moveRight();
}

sce::Gnmx::VsShader * PS4Renderer::getVertexShader()
{
	return vertexShader;
}

sce::Gnmx::PsShader * PS4Renderer::getPixelShader()
{
	return pixelShader;
}


sce::Gnmx::VsShader * PS4Renderer::LoadVsShaderFromMemory(const void * pointer)
{
	EmbeddedVsShader embeddedVsShader = { (uint32_t*)pointer };
	MemoryRequests memoryRequests;
	memoryRequests.initialize();
	embeddedVsShader.addToMemoryRequests(&memoryRequests);
	memoryRequests.m_garlic.fulfill(s_garlicAllocator.allocate(memoryRequests.m_garlic.m_sizeAlign));
	memoryRequests.m_onion.fulfill(s_onionAllocator.allocate(memoryRequests.m_onion.m_sizeAlign));
	embeddedVsShader.initializeWithMemoryRequests(&memoryRequests);
	return embeddedVsShader.m_shader;
}

sce::Gnmx::PsShader * PS4Renderer::LoadPsShaderFromMemory(const void * pointer)
{
	EmbeddedPsShader embeddedPsShader = { (uint32_t*)pointer };
	MemoryRequests memoryRequests;
	memoryRequests.initialize();
	embeddedPsShader.addToMemoryRequests(&memoryRequests);
	memoryRequests.m_garlic.fulfill(s_garlicAllocator.allocate(memoryRequests.m_garlic.m_sizeAlign));
	memoryRequests.m_onion.fulfill(s_onionAllocator.allocate(memoryRequests.m_onion.m_sizeAlign));
	embeddedPsShader.initializeWithMemoryRequests(&memoryRequests);
	return embeddedPsShader.m_shader;
}

void PS4Renderer::registerRenderTargetForDisplay(sce::Gnm::RenderTarget * renderTarget)
{
	const uint32_t kPlayerId = 0;
	int ret = sceVideoOutOpen(kPlayerId, SCE_VIDEO_OUT_BUS_TYPE_MAIN, 0, NULL);
	SCE_GNM_ASSERT_MSG(ret >= 0, "sceVideoOutOpen() returned error code %d.", ret);
	s_videoInfo.handle = ret;
	// Create Attribute
	SceVideoOutBufferAttribute attribute;
	sceVideoOutSetBufferAttribute(&attribute, SCE_VIDEO_OUT_PIXEL_FORMAT_B8_G8_R8_A8_SRGB,
		SCE_VIDEO_OUT_TILING_MODE_TILE,
		SCE_VIDEO_OUT_ASPECT_RATIO_16_9,
		renderTarget->getWidth(), renderTarget->getHeight(), renderTarget->getWidth());
	ret = sceVideoOutSetFlipRate(s_videoInfo.handle, 0);
	SCE_GNM_ASSERT_MSG(ret >= 0, "sceVideoOutSetFlipRate() returned error code %d.", ret);
	// Prepare Equeue for Flip Sync
	ret = sceKernelCreateEqueue(&s_videoInfo.eq, __FUNCTION__);
	SCE_GNM_ASSERT_MSG(ret >= 0, "sceKernelCreateEqueue() returned error code %d.", ret);
	ret = sceVideoOutAddFlipEvent(s_videoInfo.eq, s_videoInfo.handle, NULL);
	SCE_GNM_ASSERT_MSG(ret >= 0, "sceVideoOutAddFlipEvent() returned error code %d.", ret);
	s_videoInfo.flip_index = 0;
	s_videoInfo.buffer_num = 1;
	void* address[1];
	address[0] = renderTarget->getBaseAddress();
	ret = sceVideoOutRegisterBuffers(s_videoInfo.handle, 0, address, 1, &attribute);
	SCE_GNM_ASSERT_MSG(ret >= 0, "sceVideoOutRegisterBuffers() returned error code %d.", ret);
}

void PS4Renderer::requestFlipAndWait()
{
	// Set Flip Request
	int ret = sceVideoOutSubmitFlip(s_videoInfo.handle, s_videoInfo.flip_index, SCE_VIDEO_OUT_FLIP_MODE_VSYNC, 0);
	SCE_GNM_ASSERT_MSG(ret >= 0, "sceVideoOutSubmitFlip() returned error code %d.", ret);
	// Wait Flip
	SceKernelEvent ev;
	int out;
	ret = sceKernelWaitEqueue(s_videoInfo.eq, &ev, 1, &out, 0);
	s_videoInfo.flip_index = (s_videoInfo.flip_index + 1) % s_videoInfo.buffer_num;
}

void PS4Renderer::generateVsFetchShader(void * fs, uint32_t * shaderModifier, const sce::Gnmx::VsShader * vsb, const sce::Gnm::FetchShaderInstancingMode * instancingData)
{
	SCE_GNM_ASSERT_MSG(shaderModifier != 0, "shaderModifier must not be NULL.");
	SCE_GNM_ASSERT_MSG(vsb != 0, "vsb must not be NULL.");
	Gnm::FetchShaderBuildState fb = { 0 };

	Gnm::generateVsFetchShaderBuildState(&fb, &vsb->m_vsStageRegisters, vsb->m_numInputSemantics, instancingData, vsb->getVertexOffsetUserRegister(), vsb->getInstanceOffsetUserRegister());

	fb.m_numInputSemantics = vsb->m_numInputSemantics;
	fb.m_inputSemantics = vsb->getInputSemanticTable();
	fb.m_numInputUsageSlots = vsb->m_common.m_numInputUsageSlots;
	fb.m_inputUsageSlots = vsb->getInputUsageSlotTable();

	Gnm::generateFetchShader(fs, &fb);
	*shaderModifier = fb.m_shaderModifier;

}


