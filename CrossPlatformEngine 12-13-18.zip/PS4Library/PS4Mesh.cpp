#include "PS4Mesh.h"



PS4Mesh::PS4Mesh(StackAllocator *s_garlicAllocator):IMesh()
{
	

	// Allocate the vertex buffer memory
	vertexSize = 3;
	int pointsSize = vertexSize * sizeof(VertexCommon);
	vertexData = static_cast<VertexCommon*>(s_garlicAllocator->allocate(
		pointsSize, sce::Gnm::kAlignmentOfBufferInBytes));
	if (!vertexData)
	{
		printf("Cannot allocate vertex data\n");
		return;
	}

	// Allocate the vertex and index buffer memory
	indexData = static_cast<uint16_t*>(s_garlicAllocator->allocate(
		vertexSize * sizeof(uint16_t), sce::Gnm::kAlignmentOfBufferInBytes));
	if (!indexData)
	{
		printf("Cannot allocate index data\n");
		return;
	}

	vertexData[0].Position.x = -4.f;
	vertexData[0].Position.y = -2.f;
	vertexData[0].Position.z = -55.f;

	vertexData[1].Position.x = 4.f;
	vertexData[1].Position.y = -2.f;
	vertexData[1].Position.z = -55.f;

	vertexData[2].Position.x = 0.f;
	vertexData[2].Position.y = 4.f;
	vertexData[2].Position.z = -55.f;
	indexData[0] = (uint16_t)0;
	indexData[1] = (uint16_t)1;
	indexData[2] = (uint16_t)2;


	//vertexBuffer = new sce::Gnm::Buffer();


	// Initialize the vertex buffers pointing to each vertex element
	vertexBuffer->initAsVertexBuffer(
		vertexData,
		sce::Gnm::kDataFormatR32G32B32Float,
		sizeof(VertexCommon),
		vertexSize);

	//vertexBuffer->setResourceMemoryType(sce::Gnm::kResourceMemoryTypeRO);


}

PS4Mesh::PS4Mesh(VertexCommon * vb, int vbSize, uint16_t * ib, int ibSize, StackAllocator * s_garlicAllocator)
{
	vertexSize = vbSize;
	indexSize = ibSize;
	int pointsSize = vertexSize * sizeof(VertexCommon);



	vertexData = static_cast<VertexCommon*>(s_garlicAllocator->allocate(
		pointsSize, sce::Gnm::kAlignmentOfBufferInBytes));
	if (!vertexData)
	{
		printf("Cannot allocate vertex data\n");
		return;
	}

	indexData = static_cast<uint16_t*>(s_garlicAllocator->allocate(
		indexSize * sizeof(uint16_t), sce::Gnm::kAlignmentOfBufferInBytes));
	if (!indexData)
	{
		printf("Cannot allocate index data\n");
		return;
	}


	for (int i = 0; i < vertexSize; i++)
	{
		vertexData[i].Position = vb[i].Position;		
	}

	for (int i = 0; i < indexSize; i++)
	{
		indexData[i] = ib[i];
	}

	


	//vertexBuffer = new sce::Gnm::Buffer();


	// Initialize the vertex buffers pointing to each vertex element
	vertexBuffer->initAsVertexBuffer(
		vertexData,
		sce::Gnm::kDataFormatR32G32B32Float,
		sizeof(VertexCommon),
		vertexSize);
}

PS4Mesh::PS4Mesh(const char * objFile, StackAllocator * s_garlicAllocator)// :IMesh(objFile)
{
	// File input object
	std::ifstream obj(objFile);

	bool success = true;
	success = obj.good();

	// Check for successful open
	if (!obj.is_open())
		return;

	// Variables used while reading the file
	std::vector<vec3> positions;     // Positions from the file
									 // Normals from the file
	uint16_t vertCounter = 0;        // Count of vertices/indices
	char chars[100];                     // String for line reading

										 // Still have data left?
	while (obj.good())
	{
		// Get the line (100 characters should be more than enough)
		obj.getline(chars, 100);

		// Check the type of line
		if (chars[0] == 'v' && chars[1] == 'n')
		{
			// Read the 3 numbers directly into an XMFLOAT3
			vec3 norm;
			sscanf_s(
				chars,
				"vn %f %f %f",
				&norm.x, &norm.y, &norm.z);

			// Add to the list of normals
			normals.push_back(norm);
		}
		else if (chars[0] == 'v' && chars[1] == 't')
		{
			// Read the 2 numbers directly into an XMFLOAT2
			vec2 uv;
			sscanf_s(
				chars,
				"vt %f %f",
				&uv.x, &uv.y);

			// Add to the list of uv's
			uvs.push_back(uv);
		}
		else if (chars[0] == 'v')
		{
			// Read the 3 numbers directly into an XMFLOAT3
			vec3 pos;
			sscanf_s(
				chars,
				"v %f %f %f",
				&pos.x, &pos.y, &pos.z);

			// Add to the positions
			positions.push_back(pos);
		}
		else if (chars[0] == 'f')
		{
			// Read the face indices into an array
			unsigned int i[12];
			int facesRead = sscanf_s(
				chars,
				"f %d/%d/%d %d/%d/%d %d/%d/%d %d/%d/%d",
				&i[0], &i[1], &i[2],
				&i[3], &i[4], &i[5],
				&i[6], &i[7], &i[8],
				&i[9], &i[10], &i[11]);

			// - Create the verts by looking up
			//    corresponding data from vectors
			// - OBJ File indices are 1-based, so
			//    they need to be adusted
			VertexCommon v1;
			v1.Position = positions[i[0] - 1];
			v1.UV = uvs[i[1] - 1];
			v1.Normal = normals[i[2] - 1];

			VertexCommon v2;
			v2.Position = positions[i[3] - 1];
			v2.UV = uvs[i[4] - 1];
			v2.Normal = normals[i[5] - 1];

			VertexCommon v3;
			v3.Position = positions[i[6] - 1];
			v3.UV = uvs[i[7] - 1];
			v3.Normal = normals[i[8] - 1];

			// The model is most likely in a right-handed space,
			// especially if it came from Maya.  We want to convert
			// to a left-handed space for DirectX.  This means we 
			// need to:
			//  - Invert the Z position
			//  - Invert the normal's Z
			//  - Flip the winding order
			// We also need to flip the UV coordinate since DirectX
			// defines (0,0) as the top left of the texture, and many
			// 3D modeling packages use the bottom left as (0,0)

			// Flip the UV's since they're probably "upside down"
			v1.UV.y = 1.0f - v1.UV.y;
			v2.UV.y = 1.0f - v2.UV.y;
			v3.UV.y = 1.0f - v3.UV.y;

			// Flip Z (LH vs. RH)
			v1.Position.z *= -1.0f;
			v2.Position.z *= -1.0f;
			v3.Position.z *= -1.0f;

			// Flip normal Z
			v1.Normal.z *= -1.0f;
			v2.Normal.z *= -1.0f;
			v3.Normal.z *= -1.0f;

			// Add the verts to the vector (flipping the winding order)
			verts.push_back(v1);
			verts.push_back(v3);
			verts.push_back(v2);

			// Add three more indices
			indices.push_back(vertCounter); vertCounter += 1;
			indices.push_back(vertCounter); vertCounter += 1;
			indices.push_back(vertCounter); vertCounter += 1;

			// Was there a 4th face?
			if (facesRead == 12)
			{
				// Make the last vertex
				VertexCommon v4;
				v4.Position = positions[i[9] - 1];
				v4.UV = uvs[i[10] - 1];
				v4.Normal = normals[i[11] - 1];

				// Flip the UV, Z pos and normal
				v4.UV.y = 1.0f - v4.UV.y;
				v4.Position.z *= -1.0f;
				v4.Normal.z *= -1.0f;

				// Add a whole triangle (flipping the winding order)
				verts.push_back(v1);
				verts.push_back(v4);
				verts.push_back(v3);

				// Add three more indices
				indices.push_back(vertCounter); vertCounter += 1;
				indices.push_back(vertCounter); vertCounter += 1;
				indices.push_back(vertCounter); vertCounter += 1;
			}
		}
	}



	//vertexData = &verts[0];
	//indexData = &indices[0];
	vertexSize = static_cast<int>(verts.size());
	indexSize = static_cast<int>(indices.size());
	auto a = verts;


	
	
	vertexData = static_cast<VertexCommon*>(s_garlicAllocator->allocate(
		vertexSize * sizeof(VertexCommon), sce::Gnm::kAlignmentOfBufferInBytes));

	//memcpy(vertexData, verts.data(), vertexSize * sizeof(VertexCommon));

	indexData = static_cast<uint16_t*>(s_garlicAllocator->allocate(
		indexSize * sizeof(uint16_t), sce::Gnm::kAlignmentOfBufferInBytes));

	//memcpy(indexData, &indices[0], indexSize * sizeof(uint16_t));

	for (int i = 0; i < vertexSize; i++)
	{
		vertexData[i].Position = verts[i].Position;
		//vertexData[i].pad1 = verts[i].pad1;
		vertexData[i].Color = verts[i].Color;
		vertexData[i].Normal = verts[i].Normal;
		//vertexData[i].pad2 = verts[i].pad2;
		vertexData[i].UV = verts[i].UV;
		//vertexData[i].pad3 = verts[i].pad3;
	}

	for (int i = 0; i < indexSize; i++)
	{
		indexData[i] = indices[i];
	}


	//vertexBuffer = new sce::Gnm::Buffer();


	// Initialize the vertex buffers pointing to each vertex element
	vertexBuffer[0].initAsVertexBuffer(
		&vertexData[0].Position,
		sce::Gnm::kDataFormatR32G32B32Float,
		sizeof(VertexCommon),
		vertexSize);

	//vertexBuffer[1].initAsVertexBuffer(
	//	&vertexData[0].pad1,
	//	sce::Gnm::kDataFormatR32Float,
	//	sizeof(VertexCommon),
	//	vertexSize);

	vertexBuffer[1].initAsVertexBuffer(
		&vertexData[0].Color,
		sce::Gnm::kDataFormatR32G32B32A32Float,
		sizeof(VertexCommon),
		vertexSize);

	vertexBuffer[2].initAsVertexBuffer(
		&vertexData[0].Normal,
		sce::Gnm::kDataFormatR32G32B32Float,
		sizeof(VertexCommon),
		vertexSize);

	//vertexBuffer[4].initAsVertexBuffer(
	//	&vertexData[0].pad2,
	//	sce::Gnm::kDataFormatR32Float,
	//	sizeof(VertexCommon),
	//	vertexSize);

	vertexBuffer[3].initAsVertexBuffer(
		&vertexData[0].UV,
		sce::Gnm::kDataFormatR32G32Float,
		sizeof(VertexCommon),
		vertexSize);

	//vertexBuffer[6].initAsVertexBuffer(
	//	&vertexData[0].pad3,
	//	sce::Gnm::kDataFormatR32G32Float,
	//	sizeof(VertexCommon),
	//	vertexSize);


	//int vbs = vertexSize;
	//int ibs = indexSize;
	//
	//
	//std::vector<uint16_t> indexVector; 
	//indexVector = indices;

	obj.close();
}

PS4Mesh::~PS4Mesh()
{
}

sce::Gnm::Buffer * PS4Mesh::GetVertexBuffer()
{
	return vertexBuffer;
}
