#pragma once
#include"../CommonFiles/IRenderer.h"
#include"../CommonFiles/IMaterial.h"
#include"../PS4Library/PS4Renderer.h"

using namespace sce;

class PS4Material : public IMaterial
{
	sce::Gnmx::VsShader * vertexShader;
	sce::Gnmx::PsShader * pixelShader;
	const char * filename;
	Gnm::Texture* srcTexture;
	Gnm::Sampler sampler;
	//ID3D11ShaderResourceView* SRV;

	//ID3D11SamplerState*       Sampler;
	IRenderer* Renderer;
public:
	PS4Material(IRenderer* renderer, const char * obj);
	sce::Gnmx::VsShader * getvertexShader();
	sce::Gnmx::PsShader * getpixelShader();
	//ID3D11ShaderResourceView* getSRV();
	void LoadTextures();
	void DatatoShader();
	bool readRawTexture(const char* path, void *address, size_t size);
	bool readFileContents(void *data, const size_t size, FILE *fp);
	Gnm::Texture* getTexture();
	Gnm::Sampler &getSampler();
	~PS4Material();
};
