#include "PS4Material.h"
//#include"WICTextureLoader.h"

PS4Material::PS4Material(IRenderer* renderer, const char * obj)
{
	Renderer = renderer;
	
	vertexShader = dynamic_cast<PS4Renderer*>(Renderer)->getVertexShader();
	pixelShader = dynamic_cast<PS4Renderer*>(Renderer)->getPixelShader();
	filename = obj;
	LoadTextures();
}

sce::Gnmx::VsShader * PS4Material::getvertexShader()
{
	return vertexShader;
}

sce::Gnmx::PsShader * PS4Material::getpixelShader()
{
	return pixelShader;
}

bool PS4Material::readRawTexture(const char * path, void * address, size_t size)
{
	bool success = false;

	FILE *fp = fopen(path, "rb");
	if (fp != NULL)
	{
		success = readFileContents(address, size, fp);
		fclose(fp);
	}

	return success;
}



bool PS4Material::readFileContents(void *data, const size_t size, FILE *fp)
{
	if (!fp || !data)
		return false;

	uint8_t *address = static_cast<uint8_t*>(data);

	size_t bytesRead, totalBytesRead = 0;
	while (totalBytesRead < size)
	{
		bytesRead = fread(address, 1, size - totalBytesRead, fp);
		if (!bytesRead)
		{
			return false;
		}

		totalBytesRead += bytesRead;
	}

	return true;
}

Gnm::Texture* PS4Material::getTexture()
{
	return srcTexture;
}

Gnm::Sampler &PS4Material::getSampler()
{
	return sampler;
}

void PS4Material::LoadTextures()
{
	srcTexture = new Gnm::Texture();
	Gnm::TextureSpec spec;
	spec.init();
	spec.m_textureType = Gnm::kTextureType2d;
	spec.m_width = 512;
	spec.m_height = 512;
	spec.m_depth = 1;
	spec.m_pitch = 0;
	spec.m_numMipLevels = 1;
	spec.m_numSlices = 1;
	spec.m_format = Gnm::kDataFormatR8G8B8A8UnormSrgb;
	spec.m_tileModeHint = Gnm::kTileModeDisplay_LinearAligned;
	spec.m_minGpuMode = Gnm::getGpuMode();
	spec.m_numFragments = Gnm::kNumFragments1;
	//int32_t status = srcTexture.init(&spec);
	int32_t status = srcTexture->init(&spec);
	
	Gnm::SizeAlign textureSizeAlign = srcTexture->getSizeAlign();
	void *textureData = dynamic_cast<PS4Renderer*>(Renderer)->GetStackAllocater()->allocate(textureSizeAlign);
	if (!textureData)
	{
		printf("Cannot allocate the texture data\n");
		return;
	}
	
	//readRawTexture(reinterpret_cast<const char*>(filename), textureData, textureSizeAlign.m_size);
	readRawTexture(reinterpret_cast<const char*>(filename), textureData, textureSizeAlign.m_size);
	srcTexture->setBaseAddress(textureData);
	sampler.init();
	sampler.setMipFilterMode(Gnm::kMipFilterModeLinear);
	sampler.setXyFilterMode(Gnm::kFilterModeBilinear, Gnm::kFilterModeBilinear);
	//dynamic_cast<PS4Renderer*>(Renderer)->GetContext()->setSamplers(Gnm::kShaderStagePs, 0, 1, &sampler);




}
//
void PS4Material::DatatoShader()
{
	dynamic_cast<PS4Renderer*>(Renderer)->GetContext()->setTextures(Gnm::kShaderStagePs, 0, 1, srcTexture);
	//dynamic_cast<PS4Renderer*>(Renderer)->GetContext()->setTextures(Gnm::kShaderStagePs, 1, 1, &srcTexture);
	dynamic_cast<PS4Renderer*>(Renderer)->GetContext()->setSamplers(Gnm::kShaderStagePs, 0, 1, &sampler);


}


PS4Material::~PS4Material()
{
	/*SRV->Release();
	Sampler->Release();*/
	/*this->getSRV()->Release();
	this->getsamplerState()->Release();*/

}
