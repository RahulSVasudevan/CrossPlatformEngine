﻿/* SCE CONFIDENTIAL
PlayStation(R)4 Programmer Tool Runtime Library Release 02.000.071
* Copyright (C) 2013 Sony Computer Entertainment Inc.
* All Rights Reserved.
*/

#ifndef _SCE_GNM_TOOLKIT_EMBEDDED_SHADER_H
#define _SCE_GNM_TOOLKIT_EMBEDDED_SHADER_H

#include "shaderbinary.h"
#include <gnm/gpumem.h>
#include <string.h>
#include <gnmx/shader_parser.h>
#include <algorithm>
#include "memory_requests.h"


			struct EmbeddedPsShader
			{
				const uint32_t *m_source;
				sce::Gnmx::PsShader *m_shader;
				void addToMemoryRequests(MemoryRequests *memoryRequests) const;
				void initializeWithMemoryRequests(MemoryRequests *memoryRequests);
			};

	
			struct EmbeddedVsShader
			{
				const uint32_t *m_source;
				sce::Gnmx::VsShader *m_shader;
				void *m_fetchShader;
				void addToMemoryRequests(MemoryRequests *memoryRequests) const;
				void initializeWithMemoryRequests(MemoryRequests *memoryRequests);
			};

			struct EmbeddedShaders
			{
				EmbeddedPsShader **m_embeddedPsShader;
				uint32_t           m_embeddedPsShaders;
				EmbeddedVsShader **m_embeddedVsShader;
				uint32_t           m_embeddedVsShaders;
				void addToMemoryRequests(MemoryRequests *memoryRequests) const;
				void initializeWithMemoryRequests(MemoryRequests *memoryRequests);
			};
		
#endif // _SCE_GNM_TOOLKIT_EMBEDDED_SHADER_H
