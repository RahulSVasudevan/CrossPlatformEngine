﻿

#ifndef _ALLOCATOR_H_2394857
#define _ALLOCATOR_H_2394857

#include "allocator.h"
#include <sys/dmem.h>


struct StackAllocator
			{
	bool m_isInitialized;
	StackAllocator();
	~StackAllocator();
	enum {kMaximumAllocations = 8192};
	uint8_t *m_allocation[kMaximumAllocations];
	uint32_t m_allocations;
	uint8_t *m_base;
	uint32_t m_alignment;
	off_t m_offset;
	size_t m_size;
	off_t m_top;
	SceKernelMemoryType m_type;
	void init(SceKernelMemoryType type, uint32_t size);
	void *allocate(uint32_t size, uint32_t alignment);
	void *allocate(sce::Gnm::SizeAlign sizeAlign){
		return allocate(sizeAlign.m_size, sizeAlign.m_align);
	}
	void release(void* pointer);
	void deinit();
};

IAllocator GetInterface(StackAllocator *stackAllocator);
		
#endif 
