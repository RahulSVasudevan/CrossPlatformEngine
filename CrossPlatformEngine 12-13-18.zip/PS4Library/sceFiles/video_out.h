﻿/* SCE CONFIDENTIAL
 * PlayStation(R)4 Programmer Tool Runtime Library Release 02.000.071
 * Copyright (C) 2014 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */
#ifndef _SCE_VIDEO_OUT_H
#define _SCE_VIDEO_OUT_H

#include <stdint.h>
#include <kernel/equeue.h>
#include <user_service.h>
#include <sceerror.h>
#include <video_out/error.h>
#include <video_out/setting.h>
#include <device_service/device_service_error.h>

#if defined(_LANGUAGE_C_PLUS_PLUS)||defined(__cplusplus)||defined(c_plusplus)
extern "C" {
#endif

/**
 * @j 成功 @ej
 * @e success @ee
 */
#define SCE_VIDEO_OUT_OK			0	/* 0 */

enum {
	SCE_VIDEO_OUT_BUFFER_NUM_MAX =16,
	SCE_VIDEO_OUT_BUFFER_ATTRIBUTE_NUM_MAX =4,
	SCE_VIDEO_OUT_BUFFER_FLIP_RATE_MAX =2,

	SCE_VIDEO_OUT_BUFFER_INDEX_BLANK = -1,  /* special buffer index to blank screen */
	SCE_VIDEO_OUT_BUFFER_INITIAL_FLIP_ARG = -1,  /* initial flipArg valu at sceVideoOutOpen() */
};

typedef enum SceVideoOutBusType {
	SCE_VIDEO_OUT_BUS_TYPE_MAIN = 0,
} SceVideoOutBusType;


typedef enum  SceVideoOutPixelFormat {

	SCE_VIDEO_OUT_PIXEL_FORMAT_A8R8G8B8_SRGB         	= 0x80000000, /* MSB first. Blue is at LSB */
	SCE_VIDEO_OUT_PIXEL_FORMAT_B8_G8_R8_A8_SRGB			= SCE_VIDEO_OUT_PIXEL_FORMAT_A8R8G8B8_SRGB,  /* alias name in a gnm-friendly order (LSB first) */

	SCE_VIDEO_OUT_PIXEL_FORMAT_A16R16G16B16_FLOAT 		= 0xC1060000, /* MSB first. Blue is at LSB */
	SCE_VIDEO_OUT_PIXEL_FORMAT_B16_G16_R16_A16_FLOAT 	= SCE_VIDEO_OUT_PIXEL_FORMAT_A16R16G16B16_FLOAT,  /* alias name in a gnm-friendly order (LSB first) */
	
	SCE_VIDEO_OUT_PIXEL_FORMAT_A8B8G8R8_SRGB         	= 0x80002200, /* MSB first. Red is at LSB */
	SCE_VIDEO_OUT_PIXEL_FORMAT_R8_G8_B8_A8_SRGB        	= SCE_VIDEO_OUT_PIXEL_FORMAT_A8B8G8R8_SRGB,  /* alias name in a gnm-friendly order (LSB first) */

	SCE_VIDEO_OUT_PIXEL_FORMAT_A2R10G10B10				= 0x88060000, /* MSB first. Blue is at LSB */
	SCE_VIDEO_OUT_PIXEL_FORMAT_B10_G10_R10_A2			= SCE_VIDEO_OUT_PIXEL_FORMAT_A2R10G10B10,  /* alias name in a gnm-friendly order (LSB first) */

	SCE_VIDEO_OUT_PIXEL_FORMAT_A2R10G10B10_SRGB			= 0x88000000, /* MSB first. Blue is at LSB */
	SCE_VIDEO_OUT_PIXEL_FORMAT_B10_G10_R10_A2_SRGB		= SCE_VIDEO_OUT_PIXEL_FORMAT_A2R10G10B10_SRGB,  /* alias name in a gnm-friendly order (LSB first) */
} SceVideoOutPixelFormat;


typedef enum SceVideoOutFlipMode {
	SCE_VIDEO_OUT_FLIP_MODE_VSYNC	= 1,  /* on real video out vsync */
	SCE_VIDEO_OUT_FLIP_MODE_HSYNC	=	2,  /* ASAP (but not immediate) */
	SCE_VIDEO_OUT_FLIP_MODE_WINDOW=3, /* similar to vsync but may flip on some windows at the top and the bottom of the display */
} SceVideoOutFlipMode;
typedef enum SceVideoOutTilingMode {
	SCE_VIDEO_OUT_TILING_MODE_TILE=0,
	SCE_VIDEO_OUT_TILING_MODE_LINEAR=1, /* for 32bpp pixel format only */
} SceVideoOutTilingMode;


typedef enum SceVideoOutAspectRatio {
	SCE_VIDEO_OUT_ASPECT_RATIO_16_9=0,
} SceVideoOutAspectRatio;


typedef enum SceVideoOutEventId {
	SCE_VIDEO_OUT_EVENT_FLIP=0,
	SCE_VIDEO_OUT_EVENT_VBLANK=1,
} SceVideoOutEventId;

typedef struct SceVideoOutStereoBuffers {
	void *left;
	void *right;
} SceVideoOutStereoBuffers;

typedef enum SceVideoOutBufferAttributeOption {
	SCE_VIDEO_OUT_BUFFER_ATTRIBUTE_OPTION_NONE = 0,
	SCE_VIDEO_OUT_BUFFER_ATTRIBUTE_OPTION_VR   = 7,
} SceVideoOutBufferAttributeOption;

typedef struct SceVideoOutBufferAttribute {
	int32_t pixelFormat;		// SceVideoOutPixelFormat
	int32_t tilingMode;			// SceVideoOutTilingMode
	int32_t aspectRatio;		// SceVideoOutAspectRatio
	uint32_t width;
	uint32_t height;
	uint32_t pitchInPixel;
	uint32_t option;           // SceVideoOutBufferAttributeOption
	uint32_t _reserved0;
	uint64_t _reserved1;
} SceVideoOutBufferAttribute;

typedef struct SceVideoOutFlipStatus {
	uint64_t count;
	uint64_t processTime; // gpu clock of the time of the flip finished most recent
	uint64_t tsc;		  // tsc
	int64_t flipArg; // flipArg which was submitted with the flip finished most recent
	uint64_t _reserved0[2];
	int32_t gcQueueNum; // number of non-finished flips that are waiting for finishing the gc commands
	int32_t flipPendingNum;		// number of total non-finished flips
	int32_t currentBuffer;		// current buffer index on display
	uint32_t _reserved1;
} SceVideoOutFlipStatus;

typedef struct SceVideoOutVblankStatus {
	uint64_t count;
	uint64_t processTime;
	uint64_t tsc;
	uint64_t _reserved[2];
} SceVideoOutVblankStatus;

typedef struct SceVideoOutResolutionStatus {
	uint32_t fullWidth;
	uint32_t fullHeight;
	uint32_t paneWidth;
	uint32_t paneHeight;
	uint64_t refreshRate;
	float screenSizeInInch;
	uint32_t _reserved[4];
} SceVideoOutResolutionStatus;


/*
 *  basic functions
 */

int32_t sceVideoOutOpen(SceUserServiceUserId userId, int32_t type, int32_t index, const void *param);
int32_t sceVideoOutClose(int32_t handle);


/* 
 * buffer handling functions
 */
int32_t sceVideoOutRegisterBuffers(int32_t handle, int32_t startIndex, void * const *addresses, int32_t bufferNum, const SceVideoOutBufferAttribute *attribute);
int32_t sceVideoOutRegisterStereoBuffers(int32_t handle, int32_t startIndex, const SceVideoOutStereoBuffers *buffers, int32_t length, const SceVideoOutBufferAttribute *attribute);

int32_t sceVideoOutUnregisterBuffers(int32_t handle, int32_t attributeIndex);


/* 
 * flip mode options
 */

int32_t sceVideoOutSetFlipRate(int32_t handle, int32_t rate);
int32_t sceVideoOutSetWindowModeMargins(int32_t handle, int top, int bottom);


/* 
 * flip handling functions
 */
int32_t sceVideoOutSubmitFlip(int32_t handle, int32_t bufferIndex, uint32_t flipMode, int64_t flipArg);

/*
 * reading status
 */
int32_t sceVideoOutGetFlipStatus(int32_t handle, SceVideoOutFlipStatus *status);
int32_t sceVideoOutGetVblankStatus(int32_t handle, SceVideoOutVblankStatus *status);
int32_t sceVideoOutIsFlipPending(int32_t handle);
int32_t sceVideoOutGetResolutionStatus(int32_t handle, SceVideoOutResolutionStatus *status);

/* 
 * event API's
 */ 

int32_t sceVideoOutAddFlipEvent(SceKernelEqueue eq, int32_t handle, void *udata);
int32_t sceVideoOutAddVblankEvent(SceKernelEqueue eq, int32_t handle, void *udata);
int32_t sceVideoOutDeleteFlipEvent(SceKernelEqueue eq, int32_t handle);
int32_t sceVideoOutDeleteVblankEvent(SceKernelEqueue eq, int32_t handle);


int32_t sceVideoOutGetEventId(const SceKernelEvent *ev);
int32_t sceVideoOutGetEventData(const SceKernelEvent *ev, int64_t *data);
int32_t sceVideoOutGetEventCount(const SceKernelEvent *ev);



int32_t sceVideoOutWaitVblank(int32_t handle);


/*
 * utility functions
 */
void sceVideoOutSetBufferAttribute(SceVideoOutBufferAttribute *attribute, uint32_t pixelFormat, uint32_t tilingMode,
									  uint32_t aspectRatio,	uint32_t width, uint32_t height, uint32_t pitchInPixel);


/*
 * Color adjustment
 */
typedef struct SceVideoOutColorSettings {
    float    gamma[3];
    uint32_t option;
} SceVideoOutColorSettings;

// do not call this function directly
// use sceVideoOutColorSettingsSetGamma() instead
int32_t sceVideoOutColorSettingsSetGamma_(SceVideoOutColorSettings* p, float gamma, uint32_t sizeOfSettings);

// do not call this function directly
// use sceVideoOutAdjustColor() instead
int32_t sceVideoOutAdjustColor_(int32_t                   handle,
                                SceVideoOutColorSettings *pSettings,
                                uint32_t                  sizeOfSettings);


static inline int32_t sceVideoOutColorSettingsSetGamma(SceVideoOutColorSettings* p, float gamma)
{
    return sceVideoOutColorSettingsSetGamma_(p, gamma, sizeof(*p));
}

static inline int32_t sceVideoOutAdjustColor(int32_t                   handle,
                                             SceVideoOutColorSettings *pSettings)
{
    return sceVideoOutAdjustColor_(handle, pSettings, sizeof(*pSettings));
}

/*
 * Cursor
 */
#define SCE_VIDEO_OUT_CURSOR_NUM_MAX 2

typedef enum SceVideoOutCursorPendingType {
	SCE_VIDEO_OUT_CURSOR_IMAGE_ADDRESS_PENDING = 0,
	SCE_VIDEO_OUT_CURSOR_DISABLE_PENDING = 1,
} SceVideoOutCursorPendingType;

int32_t sceVideoOutCursorEnable(int32_t handle, int32_t index, const void *address);
int32_t sceVideoOutCursorDisable(int32_t handle, int32_t index);
int32_t sceVideoOutCursorSetHotSpot(int32_t handle, int32_t index, uint32_t hotX, uint32_t hotY);
int32_t sceVideoOutCursorSetPosition(int32_t handle, int32_t index, uint32_t posX, uint32_t posY);
int32_t sceVideoOutCursorSetPositionStereo(int32_t handle, int32_t index, uint32_t posX, uint32_t posY, uint32_t offset);
int32_t sceVideoOutCursorSet2xMagnify(int32_t handle, int32_t index, uint32_t enable);
int32_t sceVideoOutCursorSetImageAddress(int32_t handle, int32_t index, const void *address);
int32_t sceVideoOutCursorIsUpdatePending(int32_t handle, int32_t index, SceVideoOutCursorPendingType type);

#if defined(_LANGUAGE_C_PLUS_PLUS)||defined(__cplusplus)||defined(c_plusplus)
}
#endif

#endif /* !_SCE_VIDEO_OUT_H */
