﻿/* SCE CONFIDENTIAL
PlayStation(R)4 Programmer Tool Runtime Library Release 02.000.071
* Copyright (C) 2013 Sony Computer Entertainment Inc.
* All Rights Reserved.
*/

#include "embedded_shader.h"
#include <string.h>
#include <gnmx/shader_parser.h>
#include <algorithm>

using namespace sce;

void EmbeddedPsShader::addToMemoryRequests(MemoryRequests *memoryRequests) const
{
	Gnmx::ShaderInfo shaderInfo;
	Gnmx::parseShader(&shaderInfo, m_source);

	memoryRequests->m_garlic.request(shaderInfo.m_gpuShaderCodeSize, Gnm::kAlignmentOfShaderInBytes);
	memoryRequests->m_onion.request(shaderInfo.m_psShader->computeSize(), Gnm::kAlignmentOfBufferInBytes);
}

void EmbeddedPsShader::initializeWithMemoryRequests(MemoryRequests *memoryRequests)
{
	Gnmx::ShaderInfo shaderInfo;
	Gnmx::parseShader(&shaderInfo, m_source);

	void *shaderBinary = memoryRequests->m_garlic.redeem(shaderInfo.m_gpuShaderCodeSize, Gnm::kAlignmentOfShaderInBytes);
	void *shaderHeader = memoryRequests->m_onion.redeem(shaderInfo.m_psShader->computeSize(), Gnm::kAlignmentOfBufferInBytes);

	memcpy(shaderBinary, shaderInfo.m_gpuShaderCode, shaderInfo.m_gpuShaderCodeSize);
	memcpy(shaderHeader, shaderInfo.m_psShader, shaderInfo.m_psShader->computeSize());

	m_shader = static_cast<Gnmx::PsShader*>(shaderHeader);
	m_shader->patchShaderGpuAddress(shaderBinary);
}


void EmbeddedVsShader::addToMemoryRequests(MemoryRequests *memoryRequests) const
{
	Gnmx::ShaderInfo shaderInfo;
	Gnmx::parseShader(&shaderInfo, m_source);

	memoryRequests->m_garlic.request(shaderInfo.m_gpuShaderCodeSize, Gnm::kAlignmentOfShaderInBytes);
	memoryRequests->m_onion.request(shaderInfo.m_vsShader->computeSize(), Gnm::kAlignmentOfBufferInBytes);
}

void EmbeddedVsShader::initializeWithMemoryRequests(MemoryRequests *memoryRequests)
{
	Gnmx::ShaderInfo shaderInfo;
	Gnmx::parseShader(&shaderInfo, m_source);

	void *shaderBinary = memoryRequests->m_garlic.redeem(shaderInfo.m_gpuShaderCodeSize, Gnm::kAlignmentOfShaderInBytes);
	void *shaderHeader = memoryRequests->m_onion.redeem(shaderInfo.m_vsShader->computeSize(), Gnm::kAlignmentOfBufferInBytes);

	memcpy(shaderBinary, shaderInfo.m_gpuShaderCode, shaderInfo.m_gpuShaderCodeSize);
	memcpy(shaderHeader, shaderInfo.m_vsShader, shaderInfo.m_vsShader->computeSize());

	m_shader = static_cast<Gnmx::VsShader*>(shaderHeader);
	m_shader->patchShaderGpuAddress(shaderBinary);
}



void EmbeddedShaders::addToMemoryRequests(MemoryRequests *memoryRequests) const
{
	for(uint32_t i = 0; i < m_embeddedPsShaders; ++i)
		m_embeddedPsShader[i]->addToMemoryRequests(memoryRequests);
	for(uint32_t i = 0; i < m_embeddedVsShaders; ++i)
		m_embeddedVsShader[i]->addToMemoryRequests(memoryRequests);
}

void EmbeddedShaders::initializeWithMemoryRequests(MemoryRequests *memoryRequests)
{
	for(uint32_t i = 0; i < m_embeddedPsShaders; ++i)
		m_embeddedPsShader[i]->initializeWithMemoryRequests(memoryRequests);
	for(uint32_t i = 0; i < m_embeddedVsShaders; ++i)
		m_embeddedVsShader[i]->initializeWithMemoryRequests(memoryRequests);
}
