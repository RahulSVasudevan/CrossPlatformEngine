#pragma once

#include "..\CommonFiles\IMesh.h"
#include <sceconst.h>
#include <kernel.h>
#include <gnmx.h>
#include "sceFiles\stack_allocator.h"
#include "sceFiles\embedded_shader.h"
#include "sceFiles\shaderbinary.h"
#include "sceFiles\video_out.h"
#include "..\PS4Library\ControllerInput.h"
#include "shader_base.h"
#include <math.h>
#include <stdio.h>
#include <vectormath.h>




class PS4Mesh : public IMesh
{

	sce::Gnm::Buffer vertexBuffer[4];
	//VertexCommon* ps4vb;
	//uint16_t * ps4ib;

public:

	PS4Mesh(StackAllocator *garlicAllocator);
	PS4Mesh(VertexCommon* vb, int vbSize, uint16_t* ib, int ibSize, StackAllocator *garlicAllocator);
	PS4Mesh(const char*objFile, StackAllocator *garlicAllocator);
	~PS4Mesh();

	sce::Gnm::Buffer* GetVertexBuffer();

};