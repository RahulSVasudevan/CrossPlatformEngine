#pragma once


#include "../CommonFiles/ICamera.h"



class PS4Camera : public ICamera
{
public:
	PS4Camera();
	virtual ~PS4Camera();

	void InitialiseCamera(int height, int width);

	glm::mat4 GetViewMatrix();
	glm::mat4 GetWorldMatrix();
	glm::mat4 GetProjectionMatrix();

};
