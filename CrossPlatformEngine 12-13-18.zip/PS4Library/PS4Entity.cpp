
#include "PS4Entity.h"
//#include <WICTextureLoader.h>



void PS4Entity::setTranslation(float x, float y, float z)
{
	wmTrans += vec3(x, y, z);
	
	this->updateWorld();
	
}

void PS4Entity::setScale(float x, float y , float z)
{
	wmScale = vec3(x, y, z);
	this->updateWorld();
}

void PS4Entity::setRotation(float x, float y, float z)
{
	wmRot = vec3(x, y, z);
	this->updateWorld();
}

PS4Mesh* PS4Entity::GetMesh()
{
	return (PS4Mesh*)mesh;
}

void PS4Entity::updateWorld()
{

	worldMatrix = glm::translate(mat4(1.0f), wmTrans);

	worldMatrix = glm::scale(worldMatrix, wmScale);
	worldMatrix = glm::transpose(worldMatrix);
	//worldMatrix = glm::rotate(worldMatrix, 0.0f, wmRot);
}

mat4x4 PS4Entity::GetWorldMatrix()
{
	return worldMatrix;
}

PS4Entity::PS4Entity(IMesh* m, IMaterial* mat)
{
	mesh = m;
	material = mat;
	//Renderer = renderer;
	/*localvertexShader = dynamic_cast<WinRenderer*>(Renderer)->getVertexShader();
	localpixelShader = dynamic_cast<WinRenderer*>(Renderer)->getPixelShader();*/
	wmTrans = glm::vec3(0.0f, 0.0f, 0.0f);
	wmScale = glm::vec3(1.0f, 1.0f, 1.0f);
	wmRot = glm::vec3(0.0f,0.0f,0.0f);
	position = vec4(0.0f, 0.0f, 0.0f,1.0f);
	updateWorld();
}

PS4Entity::~PS4Entity()
{
	//delete material;
	
}
