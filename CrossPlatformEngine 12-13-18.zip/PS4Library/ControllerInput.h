﻿/* SCE CONFIDENTIAL
PlayStation(R)4 Programmer Tool Runtime Library Release 02.000.071
* Copyright (C) 2013 Sony Computer Entertainment Inc.
* All Rights Reserved.
*/

#ifndef _SCE_GNM_FRAMEWORK_CONTROLLER_H_
#define _SCE_GNM_FRAMEWORK_CONTROLLER_H_

#include"../CommonFiles/Input.h"
#include "../PS4Library/sceFiles/geommath.h"
#include <user_service.h>
#include <scetypes.h>


	/*namespace InputPS4
	{*/
	/*enum Button
	{
		BUTTON_L3 = 0x00000002,
		BUTTON_R3 = 0x00000004,
		BUTTON_OPTIONS = 0x00000008,
		BUTTON_UP = 0x00000010,
		BUTTON_RIGHT = 0x00000020,
		BUTTON_DOWN = 0x00000040,
		BUTTON_LEFT = 0x00000080,
		BUTTON_L2 = 0x00000100,
		BUTTON_R2 = 0x00000200,
		BUTTON_L1 = 0x00000400,
		BUTTON_R1 = 0x00000800,
		BUTTON_TRIANGLE = 0x00001000,
		BUTTON_CIRCLE = 0x00002000,
		BUTTON_CROSS = 0x00004000,
		BUTTON_SQUARE = 0x00008000,
		BUTTON_TOUCH_PAD = 0x00100000,
		BUTTON_INTERCEPTED = 0x80000000,
	};*/

		/*enum ButtonEventPattern
		{
			PATTERN_ANY,
			PATTERN_ALL,
		};*/

		class ControllerInput : public Input
		{
			
		public:
			static ControllerInput* getInstance()
			{
				static ControllerInput* instance = NULL;
				if (instance == NULL)
				{
					instance = new ControllerInput();
				}
				return instance;
			}
			ControllerInput(void);
			~ControllerInput(void);

			int initialize(void);
			int finalize(void);
			void update(); 


			// check whether any or all of the specified button are down
			//virtual bool isButtonDown(uint32_t buttons, ButtonEventPattern pattern = PATTERN_ALL) = 0;
			bool isButtonDown(uint32_t buttons, ButtonEventPattern pattern=PATTERN_ALL) override;
			bool isButtonUp(uint32_t buttons, ButtonEventPattern pattern=PATTERN_ALL);
			bool isButtonPressed(uint32_t buttons, ButtonEventPattern pattern=PATTERN_ALL);
			bool isButtonReleased(uint32_t buttons, ButtonEventPattern pattern=PATTERN_ALL);

			const Vector2 getLeftStick(void) const;
			const Vector2 getRightStick(void) const;

			Quat getOrientation() const;

			void setDeadZone(float deadZone);

			
			
			bool isConnected() const;
		private:


			struct AnalogStick
			{
				uint8_t x;
				uint8_t y;
			};

			struct AnalogButtons
			{
				uint8_t l2;
				uint8_t r2;
				uint8_t padding[2]; 
			};

			

			struct Data
			{
				uint32_t		buttons;		
				AnalogStick		leftStick;		
				AnalogStick		rightStick;		
				AnalogButtons	analogButtons;
				SceFQuaternion  orientation;                                       											
				SceFVector3		acceleration;	
				SceFVector3		angularVelocity;	
				bool			connected;	
				uint64_t        timestamp;	
			};

			Data m_currentPadData;
			Data m_temporaryPadData;
			Vector2	m_leftStickXY;
			Vector2	m_rightStickXY;
			Vector2	m_dummyStickXY;

			uint32_t		m_pressedButtonData;		///< The "Pressed" button event data.
			uint32_t		m_releasedButtonData;		///< The "Released" button event data.

			float					m_deadZone;
			static const float		m_defaultDeadZone;
			static const float		m_recipMaxByteAsFloat;

			int32_t m_handle;


			void updatePadData(void);
		};
	//}

#endif // _SCE_GNM_FRAMEWORK_CONTROLLER_H_
